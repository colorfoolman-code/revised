# 随包依赖及许可证

下列依赖用于恢复原源码所声明的构建环境，均保留原作者及许可证信息。第三方宏包和字体未作功能修改；宏包运行文件由官方源码生成。

| 依赖 | 版本 | 官方来源 | 许可证 |
|---|---|---|---|
| CTeX | 2.5.10 | <https://github.com/CTeX-org/ctex-kit/tree/ctex-v2.5.10> | LPPL 1.3c 或更新版本 |
| xeCJK | 3.9.1 | <https://github.com/CTeX-org/ctex-kit/tree/xeCJK-v3.9.1> | LPPL 1.3c 或更新版本 |
| zhnumber | 3.0 | <https://ctan.org/pkg/zhnumber> | LPPL 1.3c 或更新版本 |
| Noto Sans CJK SC Regular/Bold | 2.004 | <https://github.com/notofonts/noto-cjk/tree/main/Sans/OTF/SimplifiedChinese> | SIL Open Font License 1.1 |

宏包运行文件位于 `localtexmf/tex/latex`，公开源码位于 `localtexmf/source`，许可证正文及各项目原始 README 位于 `localtexmf/doc/licenses`。CTeX 2.5.10 和 xeCJK 3.9.1 与本次验证所用 TeX Live 2023 内核兼容；没有使用要求 2026 内核的新版本来增加构建门槛。

字体原文件 SHA-256：

```text
NotoSansCJKsc-Regular.otf
2c76254f6fc379fddfce0a7e84fb5385bb135d3e399294f6eeb6680d0365b74b

NotoSansCJKsc-Bold.otf
b5f0d1a190a7f9b43c310a8850630af12553df32c4c050543f9059732d9b4c0a
```

数学字体与其他常用宏包由使用者的 TeX Live 环境提供，并遵循各自的原有许可证。
