# 第一至八章数学依赖表

本文件按照 `chapters/ch01`--`chapters/ch08` 的正文编排，列出各章已经建立的定义、定理及其
使用关系。`definition` 计为正式定义；“正式结果”只计 `theorem`、`proposition`、`lemma`、
`corollary`，例、反例、评注、动机框和总结框不计入该列。

## 计数规则与总数

表中计数以正文文件中去除未转义 `%` 注释后的正式环境为准；章节文件按 `\input`/`\include`
所给的编排顺序计入。计数单位分别是精确的 `\begin{definition}`、`\begin{theorem}`、
`\begin{proposition}`、`\begin{lemma}`、`\begin{corollary}` 和 `\label{...}`。第 1--8 章
目录中的全部 `.tex` 文件均属于正文。

| 章 | 定义 | 定理 | 命题 | 引理 | 推论 | 正式结果 | 含定义合计 | 标签 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | 26 | 12 | 22 | 9 | 1 | 44 | 70 | 83 |
| 2 | 29 | 10 | 18 | 7 | 2 | 37 | 66 | 113 |
| 3 | 14 | 18 | 20 | 2 | 6 | 46 | 60 | 169 |
| 4 | 14 | 18 | 14 | 4 | 4 | 40 | 54 | 135 |
| 5 | 13 | 31 | 33 | 21 | 17 | 102 | 115 | 281 |
| 6 | 35 | 53 | 47 | 5 | 13 | 118 | 153 | 373 |
| 7 | 25 | 33 | 46 | 11 | 12 | 102 | 127 | 243 |
| 8 | 65 | 74 | 91 | 37 | 28 | 230 | 295 | 625 |
| **总计** | **221** | **249** | **291** | **96** | **83** | **719** | **940** | **2022** |

本次第一章修订后，正式结果共 719 个，含定义合计 940 项；正文标签共 2022 个，标签键均不重复。正文的 `\cref`、`\Cref`、`\ref`、`\eqref` 共出现 1484 次；展开逗号分隔参数后共 1524 个引用目标，其中 925 个不同目标，全部已定义。

八章正文源文件合计 70658 行。物理页数及第一章页码以随包 PDF 和 `REVISION_NOTES.md` 中的最终编译记录为准。本次只改写第一章；第二至八章的 `.tex` 内容与所附原源码逐字节一致。

## 允许的先修知识与证明条件

允许直接使用的先修仅为 Analysis I--II 范围内的一元与多元微积分、实数列与级数、基础度量
空间和拓扑、Banach/Hilbert 空间基本概念、有限维线性代数。测度论、概率论、Fourier 分析、
复分析、弱收敛、随机过程和随机分析不作为外部先修；它们必须由本书较早章节建立。若正文确需
良基秩、超限递归等集合论工具，必须在使用处明确陈述其角色，不能作为隐含概率论前置。

证明所需的结果遵循以下次序：跨章证明只使用较早章节；同章跨文件证明只使用编排顺序中已经
出现的内容；同一文件内的定义和结果先于首次使用。标为“后文将证明”或仅作比较、导航的前向
引用不承担当前论证。例子只使用当时已经建立的数学结果，不能替代后文定理的证明。

## 章节文件的编排顺序

下表中的 `chapter.tex` 先给出章标题和章级文字，随后按箭头所示顺序编排各正文文件；顺序按
正文出现次序而非文件名字典序排列。

| 章 | 正文文件顺序 |
|---|---|
| 1 | `chapter.tex` → `sec01_nets_filters.tex` → `sec02_compactness_countability.tex` |
| 2 | `chapter.tex` → `sec01_failures_outer_measure.tex` → `sec02_uniqueness_regularity_stieltjes.tex` → `sec03_probability_interfaces.tex` |
| 3 | `chapter.tex` → `sec01_positive_integral_and_limits.tex` → `sec02_products_signed_measures_densities.tex` → `sec03_probability_integral_interfaces.tex` |
| 4 | `chapter.tex` → `sec01_lp_density_duality.tex` → `sec02_representation_moments_weak_convergence.tex` → `sec03_probability_compactness_interfaces.tex` |
| 5 | `chapter.tex` → `sec01b_differentiation_ac_sobolev_extensions.tex` → `sec01_local_linearization_and_weak_derivatives.tex` → `sec02_density_jacobian_change_of_variables.tex` → `sec02b_density_change_variables_extensions.tex` |
| 6 | `chapter.tex` → `sec01_convolution_and_fourier.tex` → `sec01b_fourier_semigroup_extensions.tex` → `sec02_holomorphic_core.tex` → `sec02b_complex_extensions.tex` → `sec03_transforms.tex` → `sec03b_laplace_resolvent_extensions.tex` → `sec04_semigroup_probability_interfaces.tex` |
| 7 | `chapter.tex` → `sec01_laws_independence_products.tex` → `sec01b_probability_models_extensions.tex` → `sec02_conditioning_martingales.tex` → `sec02b_conditioning_martingale_extensions.tex` → `sec02c_branching_process_case_study.tex` |
| 8 | `chapter.tex` → `sec01_limit_laws_and_clt.tex` → `sec01b_limit_theory_extensions.tex` → `sec01c_ergodic_theory.tex`，其内依次输入 `sec01c_a_ergodic_foundations.tex`、`sec01c_b_ergodic_pointwise.tex`、`sec01c_c_ergodic_models_stationary.tex` → `sec02_markov_and_brownian.tex` 的原 Markov 部分 → 该文件内嵌的 `sec02b_markov_extensions.tex` → `sec02_markov_and_brownian.tex` 的原 Gaussian/Brownian 部分 → `sec02c_brownian_extensions.tex` → `sec03_continuous_time_stochastic_calculus.tex` |

第 8 章的遍历论文件及其三个子文件排在极限定理之后、Markov 内容之前；这一部分先建立保测
系统与严格平稳过程的时间平均理论。有限 Markov 链随后直接证明任意初始分布下的遍历平均。
`sec02b_markov_extensions.tex` 位于 `sec02_markov_and_brownian.tex` 的 Markov 小节与
Gaussian/Brownian 小节之间。因此离散强 Markov、Green 核、再生、混合、Poisson 方程和有限
状态连续时间链均先于 Wiener 路径理论。

## 第一至六章的主要结果

| 范围 | 已建立内容 | 相关标签 | 后续数学用途 |
|---|---|---|---|
| 第 1 章 | 网、滤子、乘积与紧性；可数性、Baire、局部紧性；函数族紧性 | `ch1:thm:arzela-ascoli` | 第 4 章路径集紧性；第 8 章路径律 tightness |
| 第 2 章基础 | 外测度、延拓/唯一性、完备化、正则性、Stieltjes 测度；概率空间、随机变量、推前与律 | `ch2:def:probability-space`、`ch2:def:random-variable`、`ch2:def:pushforward-measure`、`ch2:def:law-of-random-element`、`ch2:prop:finite-measure-uniqueness` | 全部概率对象与路径律 |
| 第 2 章概率结构 | CDF 的单调/右连续/端点结构；广义分位及反演；可数生成、Polish、标准 Borel、可数积 Polish | `ch2p:prop:cdf-structure`、`ch2p:def:generalized-quantile`、`ch2p:prop:quantile-inversion`、`ch2p:def:countably-generated-space`、`ch2p:def:polish-standard-borel`、`ch2p:prop:polish-borel-countable`、`ch2p:prop:countable-product-polish` | 第 7 章分位与正则条件律；第 8 章 Skorokhod/Wiener 路径空间 |
| 第 3 章基础 | Lebesgue 积分、MCT/Fatou/DCT/Vitali、乘积测度、Tonelli--Fubini、Hahn--Jordan、总变差、Radon--Nikodym | `thm:ch3-mct`、`thm:ch3-dct`、`thm:ch3-tonelli`、`thm:ch3-fubini`、`thm:ch3-radon-nikodym` | 期望、联合律、条件密度与全部随机积分前的普通积分 |
| 第 3 章概率结构 | 非负尾积分与任意正阶矩；可变号尾平衡（至少一个单边尾积分有限时扩展期望有定义，两边都有限恰为可积）；概率核及联合可测参数积分 | `ch3p:thm:tail-moment-formulas`、`ch3p:prop:signed-tail-balance`、`ch3p:def:probability-kernel`、`ch3p:thm:kernel-parameter-measurability` | 第 7 章随机级数/核演算；第 8 章尾和、Markov 核、桥核、半群核 |
| 第 4 章基础 | `L^p`、Hilbert 投影、Bochner 积分、Riesz--Markov、narrow 收敛、Portmanteau、tightness | `thm:ch4-riesz-markov`、`thm:ch4-portmanteau`、`thm:ch4-bounded-lipschitz-metric` | 条件期望存在、弱收敛和 Banach 值半群积分 |
| 第 4 章概率结构 | `L^p` 控制的一致可积模量；narrow 相对紧；连续路径空间的 Polish/Borel 结构和 Ascoli 判据 | `ch4p:prop:lp-uniform-integrability-moduli`、`ch4p:def:narrow-relative-compactness`、`ch4p:prop:bounded-gaussian-family`、`ch4p:thm:path-space-polish-rational-borel`、`ch4p:cor:path-space-ascoli-interface` | 第 7 章鞅收敛；第 8 章函数型 tightness、Wiener 测度与路径泛函 |
| 第 5 章 | Fréchet/Taylor/逆与隐函数；AC/BV/Sobolev；极大函数、Lebesgue 点、Rademacher；Jacobian 与单射/有限分支变量代换 | `ch5a:quantitative-inverse-theorem`、`ch5:lebesgue-differentiation-theorem`、`ch5:change-of-variables`、`ch5b:finite-branch-density` | 密度变换与第 6 章 Fourier/卷积分析；不提供随机过程前置 |
| 第 6 章基础 | 卷积、近似恒等族、Fourier 唯一性/反演/Plancherel、热核；复分析；Laplace/Stieltjes/有限维 resolvent | `ch6:gaussian-semigroup-proposition`、`ch6f:plancherel-core-independence`、`ch6f:heat-generator-limit`、`ch6t:laplace-transform-def`、`ch6t:hermitian-residue-projection` | 第 7 章特征函数；第 8 章 Lévy/CLT 与生成元例 |
| 第 6 章半群理论 | Banach 空间强连续收缩半群；Gaussian `C_0` 正收缩半群及核合成；Bochner--Laplace 预解式与指数时间逼近 | `ch6p:def:strong-contraction-semigroup`、`ch6p:prop:gaussian-c0-semigroup`、`ch6p:eq:gaussian-kernel-composition`、`ch6p:thm:laplace-resolvent-identity`、`ch6p:eq:laplace-resolvent-identity`、`ch6p:cor:exponential-time-approximation` | 第 8 章 Feller 半群、热半群、生成元与预解式 |

### 定义的首次出现与使用范围

| 概念 | 首次定义处 | 后续文件的使用范围 |
|---|---|---|
| 广义分位函数 | `ch2p:def:generalized-quantile`；基本反演为 `ch2p:prop:quantile-inversion` | `ch7p:def:tail-atom-quantile` 只统一尾、原子与分位记号；`ch7p:prop:quantile-inverse-geometry`、`ch7p:thm:quantile-transform` 和 `ch8l:prop:quantile-coupling` 在此基础上加结论，不重定义一般分位函数 |
| Polish/标准 Borel | `ch2p:def:polish-standard-borel`，可数结构见 `ch2p:prop:polish-borel-countable`、`ch2p:prop:countable-product-polish` | 第 7 章由 `prop:ch7-standard-borel-coding` 推进到 `thm:ch7-regular-conditional-law`；第 7 章不重新定义标准 Borel |
| 概率核与参数积分 | `ch3p:def:probability-kernel`、`ch3p:thm:kernel-parameter-measurability` | `ch7m:ker:actions-definition` 扩展到次概率核/核作用；随后建立联合测度、合成和析取，不重复一般概率核定义 |
| 连续路径空间 | `ch4p:thm:path-space-polish-rational-borel`、`ch4p:cor:path-space-ascoli-interface` | `ch8l:prop:c01-polish-rational` 与 `ch8b:prop:rational-coordinates-generate` 专门处理目标稠密集或零起点子空间 |
| 强连续半群、热半群、Laplace 预解式 | `ch6p:def:strong-contraction-semigroup`、`ch6p:prop:gaussian-c0-semigroup`、`ch6p:thm:laplace-resolvent-identity` | 第 8 章只增加正性/Feller 语义、生成元定义域、生成元逆关系和 Dynkin 鞅 |

## 第七章：概率律、核、鞅与分枝过程

第七章使用第 2 章的概率对象与标准 Borel 结构、第 3 章的积分/乘积律/概率核、第 4 章的
`L^p`/Hilbert/一致可积/窄收敛，以及第 6 章的特征函数；证明不取用第 8 章的结果。

| 数学主题 | 所需先行结果 | 本主题建立的结果 |
|---|---|---|
| `sec01_laws_independence_products`：收敛、独立、扩张 | 第 2--4 章的律、积分、乘积测度、UI、tightness；第 6 章特征函数 | `thm:ch7-vitali-interface`、`thm:ch7-independence-product-law`、`thm:ch7-borel-cantelli`、`thm:ch7-kolmogorov-zero-one`、`thm:ch7-kolmogorov-extension` |
| `sec01b_probability_models_extensions`：CDF、尾、分位、随机序 | 第 2 章的分位定义与反演以及第 3 章尾积分 | `ch7p:def:tail-atom-quantile`、`ch7p:prop:cdf-tail-atom-identities`、`ch7p:prop:quantile-inverse-geometry`、`ch7p:thm:quantile-transform`、`ch7p:prop:tail-quantile-integrals`、`ch7p:prop:stochastic-order-quantiles` |
| 同文件：可数状态总变差与耦合 | 独立乘积律、可数状态上的和与测度唯一性 | `ch7p:def:countable-total-variation`、`ch7p:thm:countable-tv-formulas`、`ch7p:thm:maximal-coupling-countable`、`ch7p:prop:tv-pushforward-product` |
| 同文件：生成类独立与随机级数 | 第 3 章期望/方差，第 7 章独立性与 Borel--Cantelli | `ch7p:thm:independent-generating-classes`、`ch7p:def:random-series-convergence`、`ch7p:thm:kolmogorov-maximal-inequality`、`ch7p:thm:summable-variance-series`、`ch7p:thm:levy-maximal-inequality`、`ch7p:thm:kolmogorov-three-series`、`ch7p:thm:rademacher-series-criterion`、`ch7p:thm:nonnegative-truncated-expectation`、`ch7p:thm:biased-sign-series` |
| `sec02_conditioning_martingales`：条件期望与正则条件律 | 第 4 章 Hilbert 投影；第 2 章标准 Borel；第 3 章概率核 | `thm:ch7-ce-existence`、`prop:ch7-ce-properties`、`prop:ch7-total-covariance`、`prop:ch7-standard-borel-coding`、`thm:ch7-regular-conditional-law`、`prop:ch7-conditional-independence-kernel` |
| 同文件：离散鞅与收敛 | 条件期望及 UI/Vitali | `prop:ch7-doob-decomposition`、`prop:ch7-predictable-quadratic-variation`、`thm:ch7-doob-maximal`、`prop:ch7-bounded-stopping`、`thm:ch7-optional-sampling-ui`、`lem:ch7-doob-upcrossing`、`thm:ch7-doob-as-convergence`、`thm:ch7-ui-martingale-convergence`、`cor:ch7-levy-upward` |
| `sec02b_conditioning_martingale_extensions`：有限条件计算 | 条件期望存在、塔式性质、密度与普通 Fubini | `ch7m:fi:countable-atoms`、`ch7m:fi:finite-bayes`、`ch7m:fi:beta-bernoulli`、`ch7m:fi:gaussian-conditioning`、`ch7m:fi:conditional-square-risk` |
| 同文件：核演算与析取 | 第 3 章概率核/参数积分；正则条件律 | `ch7m:ker:actions-definition`、`ch7m:ker:parameter-integral`、`ch7m:ker:joint-measure-fubini`、`ch7m:ker:composition`、`ch7m:ker:disintegration` |
| 同文件：条件中位数与条件独立 | 第 3 章联合可测参数积分、正则条件律与前段核演算 | `ch7m:med:random-integrand`、`ch7m:med:definition`、`ch7m:med:absolute-loss`、`ch7m:ci:event-equivalence`、`ch7m:ci:information-screening` |
| 同文件：鞅差、变换与离散 brackets | 条件期望、离散鞅及 `L^2` 正交 | `ch7m:mt:transform-definition`、`ch7m:mt:transform-martingale`、`ch7m:mt:l2-isometry`、`ch7m:mt:two-brackets`、`ch7m:mt:bracket-compensation`、`ch7m:mt:product-likelihood` |
| 同文件：class D 与抽样 | 有界抽样、UI 抽样、Doob 最大不等式 | `ch7m:os:class-d-definition`、`ch7m:os:closed-sampling`、`ch7m:os:two-criteria`、`ch7m:os:gambler-ruin` |
| 同文件：反向鞅 | 第 4 章 `L^p`/UI/Vitali、条件期望塔式性质与前文普通鞅收敛 | `ch7m:rev:lp-tail-maximal`、`ch7m:rev:definition`、`ch7m:rev:closed-by-first`、`ch7m:rev:downward`、`ch7m:rev:tail-conditioning`、`ch7m:rev:iid-averages` |
| `sec02c_branching_process_case_study`：Galton--Watson | 独立乘积律、条件期望、总协方差、Doob/UI/Vitali 收敛及 `ch7m:mt:l2-isometry` | `ch7g:def:model` → `ch7g:prop:one-step` → `ch7g:prop:iteration`；`ch7g:def:extinction` → `ch7g:thm:smallest-fixed-point` → `ch7g:thm:classification`；`ch7g:prop:additive-martingale` → `ch7g:thm:l2-convergence` |

随机级数部分依次使用生成类独立性、中心独立项正交、Kolmogorov 最大不等式、可和方差级数、
Lévy 最大不等式与对称化、两级数判据、三列定理及专门判据。条件概率部分依次建立条件期望、
标准 Borel 编码、正则条件律、核的参数积分、核诱导的联合测度、核合成和条件独立。反向鞅在
定义与闭合表示之后才得到向下收敛和尾 σ-代数结论。Galton--Watson 文件只使用此前第七章
已经证明的结果。

## 第八章：极限、遍历论、Markov、Wiener 路径与随机分析

### 极限定理与函数型极限

| 数学主题 | 所需先行结果 | 本主题建立的结果 |
|---|---|---|
| 弱/强大数律与随机级数方法 | 第 7 章独立性、Borel--Cantelli、随机级数；第 3 章尾积分 | `thm:ch8-kolmogorov-maximal`、`thm:ch8-kolmogorov-slln`、`ch8l:lem:integer-tail-sum`、`ch8l:lem:truncated-layer-sum`、`ch8l:prop:variance-growth-slln`、`ch8l:thm:slln-integrability-necessary` |
| Chernoff、Hoeffding、Azuma、McDiarmid | Markov 不等式、独立乘积律、条件期望和有界鞅差 | `ch8l:def:log-mgf-domain`、`ch8l:prop:log-mgf-convex`、`ch8l:thm:chernoff-variational`、`ch8l:lem:conditional-hoeffding`、`ch8l:thm:azuma-hoeffding`、`ch8l:prop:maximal-azuma`、`ch8l:prop:bounded-differences` |
| 一维弱收敛与 Skorokhod 表示 | 第 2 章分位/Polish；第 4 章 Portmanteau；Prokhorov 与弱拓扑度量化 | `ch8l:thm:cdf-criterion`、`ch8l:prop:quantile-coupling`、`ch8l:thm:skorokhod-representation`、`ch8l:thm:extended-mapping` |
| 三角阵与稀有事件 | 特征函数、Lévy 连续性、最大耦合 | `thm:ch8-lindeberg-triangular`、`ch8l:prop:lyapunov-lindeberg-feller`、`ch8l:thm:lindeberg-feller-equivalence`、`ch8l:thm:le-cam-poisson` |
| 路径空间 tightness 与有限维提升 | 第 4 章路径 Polish/Ascoli，以及本章此前的 Prokhorov 定理 | `ch8l:prop:c01-polish-rational`、`ch8l:thm:c-tightness-modulus`、`ch8l:thm:kolmogorov-tightness`、`ch8l:thm:fdd-tightness-lifting`、`ch8l:cor:donsker-functional-interface` |
| 经典与多元 CLT | 第 6 章特征函数、第 7 章独立乘积律，以及本章此前的 Lévy 连续性；多元情形另用 Cramér--Wold 与经典 CLT | `thm:ch8-classical-clt`、`thm:ch8-multivariate-clt` |
| Donsker 不变性原理 | Lindeberg 三角阵、Brownian 存在、Cramér--Wold，以及此前建立的路径 tightness 判据 | `thm:ch8-donsker` |

条件 Hoeffding 中的端点是有限的前一时刻可测随机变量。条件中心性给出 `A <= 0 <= B`，
在 `{B-A >= 1/m}` 上可以提出倒数。McDiarmid 的证明先由乘积律、参数积分和有理阈值构造
可测的条件本质上下端点，再应用 Azuma 不等式。对数矩母函数按扩展实值凸函数处理，零点邻域
的指数矩条件只在需要时另行假设。

### 遍历理论与平稳过程

本二级节的直接严格前置是第 3 章的积分收敛与 Tonelli--Fubini、第 4 章的 Hilbert 投影与
`L^p`/一致可积、第 7 章的条件期望、乘积独立、Kolmogorov 扩张和零一律，以及本章此前的
强大数律。所有变换均在概率空间上讨论，除非专门说明，不假定可逆。

| 数学主题 | 所需先行结果 | 本主题建立的结果 |
|---|---|---|
| 保测变换、Koopman 算子与不变信息 | 概率空间、推前测度、`L^p` 与条件期望 | `ch8e:def:measure-preserving`、`ch8e:def:koopman`、`ch8e:prop:koopman-isometry`、`ch8e:def:invariant-sigma-field`、`ch8e:lem:exact-invariant-representative`、`ch8e:prop:fixed-functions-invariant-sigma` |
| Poincaré 返归 | 保测性、非负积分和有限总质量 | `ch8e:def:return-time-wandering`、`ch8e:thm:poincare-recurrence`、`ch8e:cor:positive-set-recurrence` |
| `L^2` 均值遍历定理 | Koopman 等距、Hilbert 正交投影，以及固定函数与不变信息的识别 | `ch8e:def:fixed-space-coboundary`、`ch8e:prop:coboundary-telescoping`、`ch8e:prop:fixed-coboundary-decomposition`、`ch8e:thm:von-neumann-mean-ergodic`、`ch8e:cor:mean-ergodic-conditional-expectation` |
| Hopf 最大引理与点态收敛 | 保测性、`L^1` 收缩、截断、Markov 不等式及第 7 章条件期望 | `ch8e:lem:maximal-ergodic`、`ch8e:cor:maximal-weak-one-one`、`ch8e:lem:orbit-term-sublinear`、`ch8e:prop:dense-class-pointwise`、`ch8e:lem:maximal-density-extension`、`ch8e:prop:birkhoff-finite-limit-exists` |
| Birkhoff 定理与访问频率 | 前项点态有限极限、极限不变性、截断所得一致可积和 Vitali | `ch8e:lem:birkhoff-limit-invariant`、`ch8e:lem:ergodic-averages-ui`、`ch8e:thm:birkhoff-pointwise`、`ch8e:cor:visit-frequency` |
| 遍历性、强混合与经典模型 | Birkhoff 定理、生成类独立性、`L^1` 平移连续性和 Dynkin 类方法 | `ch8e:def:ergodic`、`ch8e:prop:ergodic-equivalences`、`ch8e:def:strong-mixing`、`ch8e:prop:strong-mixing-correlation`、`ch8e:prop:mixing-implies-ergodic`、`ch8e:prop:bernoulli-shift-mixing`、`ch8e:prop:rotation-ergodicity`、`ch8e:prop:doubling-map-mixing` |
| 严格平稳过程与时间平均 | 标准 Borel 可数积、路径律、移位保测性与 Birkhoff 定理 | `ch8e:def:strictly-stationary-sequence`、`ch8e:def:second-order-stationary-sequence`、`ch8e:prop:stationarity-shift-invariance`、`ch8e:prop:finite-window-path-representation`、`ch8e:thm:stationary-process-ergodic`、`ch8e:cor:stationary-ergodic-lln` |

证明关系依次为：保测性给出 Koopman 等距；模零不变 σ-代数及严格不变代表元识别固定函数空间；
固定空间与余边界的正交分解推出 von Neumann 均值遍历定理；Hopf 有限最大部分和给出弱
`(1,1)` 估计，结合轨道尾项次线性、稠密类收敛和振荡控制得到 `L^1` 点态极限；极限不变性与
一致可积性再确定其条件期望。由此定义遍历性和强混合，并用 Bernoulli 移位、无理旋转和倍增
映射区分“遍历”“混合”“可逆”。

平稳过程部分先区分严格平稳与二阶平稳，再证明典范路径律在左移位下保测，最后应用 Birkhoff。
隐藏参数 Bernoulli 混合例 `ch8e:ex:hidden-parameter-stationary-mixture` 表明：平稳性只给出
不变条件期望这一随机极限；路径移位遍历时，该极限才退化为常数。Markov 链的平稳分布采用
这里的严格平稳语义，路径移位 `ch8k:def:path-shift` 是左移位的迭代专门化。平稳 OU 的固定
步长抽样若要得到常数极限，还需要证明相应离散移位的遍历性；平稳性本身不蕴含遍历性。

### 离散与连续时间 Markov 理论

| 数学主题 | 所需先行结果 | 本主题建立的结果 |
|---|---|---|
| Markov 路径律、Chapman--Kolmogorov 与平稳律 | 第 2 章 Carathéodory 延拓/唯一性、第 3 章概率核/参数积分、第 7 章有界函数单调类 `lem:ch7-bounded-function-monotone-class`；“平稳”采用此前 `ch8e:def:strictly-stationary-sequence` 的有限维移位不变语义；紧空间不变律另用本章此前的 Prokhorov、第 4 章弱收敛结果与 Feller 弱连续性 | `thm:ch8-ionescu-tulcea`、`prop:ch8-chapman-kolmogorov`、`thm:ch8-compact-feller-invariant`、`thm:ch8-finite-stationary` |
| 有限链混合、谱与加性泛函 | 已建立的有限链平稳律、第 7 章总变差耦合/离散鞅、有限维自伴谱定理，以及本章强大数律与 Lévy 连续性；再生平均的证明在本节直接使用停时分层公式 | `thm:ch8-finite-mixing`、`thm:ch8-reversible-spectral`、`thm:ch8-finite-ergodic-average`（同一结果亦标作 `ch8k:thm:renewal-reward-lln`）、`prop:ch8-markov-poisson-decomposition`（同时标作 `ch8k:prop:poisson-canonical-solution`）、`ch8k:def:poisson-asymptotic-variance`、`thm:ch8-markov-additive-clt`（同时标作 `ch8k:thm:additive-clt-any-initial`） |
| 状态分类与离散强 Markov | 已构造的 Markov 路径律、Markov 条件期望式，以及第 7 章停时/条件期望结果 | `ch8k:def:access-classes`、`ch8k:def:hitting-return`、`ch8k:def:period`、`ch8k:thm:strong-markov-finite-future`、`ch8k:thm:strong-markov-path` |
| 杀死链、Green 核与边值问题 | 离散强 Markov、非负求和和有限状态线性代数 | `ch8k:def:killed-green`、`ch8k:prop:killed-transition-occupation`、`ch8k:thm:finite-fundamental-matrix`、`ch8k:thm:hitting-minimal-harmonic`、`ch8k:thm:cost-minimal-poisson`、`ch8k:cor:green-representation` |
| 再生块与 Kac 公式 | 离散强 Markov、有限不可约性，以及前面已证明的回返几何尾估计与周期收益比 | `ch8k:prop:finite-return-geometric-tail`、`ch8k:def:regeneration-blocks`、`ch8k:thm:excursions-iid`、`ch8k:thm:kac-single-state`、`ch8k:thm:kac-set`；任意初始律的 renewal--reward 大数律只回指前述 `ch8k:thm:renewal-reward-lln`，不在此重复证明 |
| 定量混合与 Poisson 方差细化 | 此前有限链平稳/混合、规范 Poisson 解、鞅分解、渐近方差、任意初始律 CLT，以及有限维谱定理 | `ch8k:def:dobrushin-coefficient`、`ch8k:thm:dobrushin-contraction`、`ch8k:def:spectral-gaps`、`ch8k:thm:spectral-gap-mixing`、`ch8k:prop:poisson-neumann-series`、`ch8k:thm:poisson-variance-identities`、`ch8k:prop:finite-sample-covariance-variance`、`ch8k:prop:zero-asymptotic-variance`、`ch8k:thm:reversible-spectral-variance` |
| Poisson 过程与有限状态 CTMC | 第 7 章 iid 乘积构造、条件期望与离散鞅，第 8 章强大数律，以及有限矩阵指数 | `ch8k:def:poisson-process-construction`、`ch8k:thm:poisson-independent-increments`、`ch8k:thm:poisson-thinning`、`ch8k:prop:poisson-compensated-martingales`、`ch8k:def:finite-q-matrix`、`ch8k:thm:finite-ctmc-uniformization`、`ch8k:prop:ctmc-short-time-rates`、`ch8k:prop:ctmc-stationarity` |

Markov 部分先建立路径构造、有限链的平稳性/混合性/谱性质，再证明任意初始律下的再生遍历
平均；随后给出规范 Poisson 解与鞅--端点分解、Poisson 渐近方差、有界鞅差 CLT 和任意初始律的
加性 CLT。这四项结论的完整证明均在此处。接着讨论 `sec02b_markov_extensions.tex`：状态分类与
停时导出离散强 Markov 性，再得到 Green 核和边值问题；回返高阶矩导出 iid 再生块以及单点、集合
Kac 公式；Dobrushin 系数或谱隙给出 Poisson 解的 Neumann 表示、渐近方差的能量差、Green--Kubo
公式、有限样本公式、零方差判据和可逆谱表达式。Poisson 等待时构造给出独立增量、thinning 和
补偿鞅，Q 矩阵随后给出 uniformization、短时率与平稳性。极限定理中的 Poisson 参数满足
`lambda >= 0`，零参数时为点质量 `delta_0`；等待时构造取正速率，零速率过程约定为恒零过程。
到达次序统计量只在 `t > 0`、`n >= 1` 下陈述，吸收状态 `q_i = 0` 在 thinning 公式中单独处理。
跳过程部分不使用后面的连续鞅 Itô 理论。

### Gaussian、Wiener 测度与 Brownian 强 Markov 性

| 数学主题 | 所需先行结果 | 本主题建立的结果 |
|---|---|---|
| Gaussian 有限维律与连续 Brownian 版本 | 第 6 章特征函数/Fourier 唯一性、第 7 章 Kolmogorov 扩张，以及允许先修中的半正定线性代数 | `prop:ch8-gaussian-kernel-existence`、`thm:ch8-kolmogorov-continuity`、`thm:ch8-brownian-existence`、`prop:ch8-brownian-future-independence` |
| 退化 Gaussian 与 Wiener 路径律 | 半正定谱分解；第 4 章路径 Polish/Borel；连续 Brownian 版本 | `ch8b:def:degenerate-gaussian-support`、`ch8b:prop:degenerate-gaussian-geometry`、`ch8b:def:wiener-measure`、`ch8b:thm:wiener-measure-existence-uniqueness`、`ch8b:prop:path-functional-measurability` |
| Brownian 桥核 | Gaussian 线性变换、路径 Borel、概率核/析取 | `ch8b:prop:tied-down-brownian-bridge`、`ch8b:def:brownian-bridge-kernel`、`ch8b:prop:bridge-conditional-path-law`、`ch8b:prop:bridge-finite-dimensional-density`、`ch8b:cor:bridge-local-absolute-continuity` |
| 通常增广与 Brownian 强 Markov | Brownian 原始自然滤过与确定时刻未来独立性、第 2 章完备化、第 4 章路径 Borel/有理坐标，以及第 7 章条件期望/抽样 | `ch8b:def:usual-augmentation`、`ch8b:prop:augmented-fixed-time-independence`、`ch8b:def:continuous-stopping-sigma-field`、`ch8b:lem:stopping-information-facts`、`ch8b:lem:simple-stopping-restart`、`ch8b:thm:brownian-strong-markov`、`ch8b:cor:stopping-semigroup` |
| 首达、最大值与退出 | Brownian 强 Markov、Gaussian 对称性、连续路径的首达时可测性与第 7 章可选抽样 | `ch8b:prop:maximum-terminal-reflection`、`ch8b:prop:hitting-density-laplace`、`ch8b:cor:hitting-moment-threshold`、`ch8b:prop:basic-brownian-martingales`、`ch8b:thm:interval-exit`、`ch8b:prop:discounted-interval-exit` |
| 路径粗糙性与确定分割平方和 | Gaussian 尾、独立 dyadic 增量、Borel--Cantelli、连续性 | `ch8b:thm:brownian-modulus-upper`、`ch8b:cor:all-subcritical-holder`、`ch8b:thm:no-critical-holder-interval`、`ch8b:thm:brownian-nowhere-differentiable`、`ch8b:thm:deterministic-partition-qv`、`ch8b:prop:deterministic-partition-power-sums`、`ch8b:cor:brownian-p-variation-bounds` |

通常增广后的确定时刻独立性由如下逼近得到：把未来增量从 `s+epsilon` 起算，使用原始独立
增量，再由路径连续性令 `epsilon` 下降到 0。对有限值停时分层并作 dyadic 上逼近，结合有界
停时极限与 `tau wedge m` 局部化，便得到 Brownian 强 Markov 性；有理坐标柱函数再将结论推广
到整条未来 Wiener 路径。一般停时的因子分解带有 `1_{tau < infinity}`；当 `tau < infinity` a.s.
时，重启路径才无条件独立于停止信息且具有 Wiener 律。平方和结论的量词如下：预先固定的细分
割给出 `L^2` 或概率收敛；网格长度可和时由 Borel--Cantelli 得到几乎处处收敛；路径依赖分割
不在该结论的范围内。

### 连续鞅、二次变差、Itô 积分与 SDE

| 数学主题 | 所需先行结果 | 本主题建立的结果 |
|---|---|---|
| Feller 半群、生成元、预解式、Dynkin | 第 6 章强连续收缩半群、Gaussian `C_0` 半群、Laplace 预解式；第 8 章 Markov 性 | `ch8s:def:feller-semigroup`、`ch8s:def:feller-generator`、`ch8s:def:laplace-resolvent`、`ch8s:thm:resolvent-generator`、`ch8s:def:feller-process`、`ch8s:thm:dynkin-martingale`、`ch8s:cor:stopped-dynkin` |
| 连续鞅、局部化与抽样 | 通常条件、停止信息、条件期望 UI 与第 7 章离散抽样 | `ch8s:def:continuous-local-martingale`、`ch8s:def:class-d-ucp`、`ch8s:thm:bounded-optional-sampling`、`ch8s:prop:localization-basics`、`ch8s:thm:class-d-closed-representation` |
| 连续局部鞅二次变差 | 前段连续局部鞅/局部化、第 7 章离散鞅的 `L^2` 正交与最大估计，以及第 4 章 `L^2` 完备性/UI；可预测 σ-代数在 angle bracket 定义之前建立 | `ch8s:lem:discrete-quadratic-sum-bound`、`ch8s:lem:nested-quadratic-sums`、`ch8s:lem:ucp-ui-martingale-limit`、`ch8s:lem:stopping-quadratic-sums`、`ch8s:thm:continuous-local-martingale-qv`、`ch8s:def:predictable-sigma-field`、`ch8s:def:continuous-process-bracket`、`ch8s:def:covariation-angle-bracket`、`ch8s:prop:finite-variation-zero-qv`、`ch8s:cor:brownian-bracket` |
| 可预测过程与 Brownian Itô 积分 | 相对于同一通常滤过的 Brownian 运动及其条件正交、第 3 章乘积积分，以及第 4 章 `L^2` 稠密性与完备性 | `ch8s:def:predictable-step-process`、`ch8s:thm:predictable-step-density`、`ch8s:def:step-ito-integral`、`ch8s:prop:step-ito-isometry`、`ch8s:thm:ito-integral-extension`、`ch8s:thm:stopped-ito-integral`、`ch8s:def:local-ito-integral`、`ch8s:prop:ito-integral-bracket` |
| Brownian 与 Itô 过程公式 | 已建立的 Brownian bracket、Itô 积分/等距/最大估计，以及第 5 章 Taylor 公式 | `ch8s:lem:three-ito-partition-limits`、`ch8s:lem:ito-taylor-remainder`、`ch8s:thm:brownian-ito-formula`、`ch8s:thm:time-dependent-ito`、`ch8s:def:one-dimensional-ito-process`、`ch8s:thm:ito-process-formula` |
| 多维积分与多维公式 | 各 Brownian 坐标的积分、协变差极化与局部化 | `ch8s:lem:multidimensional-integral-covariation`、`ch8s:thm:multidimensional-ito` |
| 扩散算子与 Feynman--Kac 验证 | Itô 过程公式、可积性和平方可积随机积分均值为零 | `ch8s:def:diffusion-generator`、`ch8s:prop:diffusion-dynkin`、`ch8s:thm:feynman-kac-verification` |
| 全局 Lipschitz SDE | 相对于同一滤过的 Brownian 运动、Brownian Itô 积分/最大估计、适应与可预测可测性，以及 `L^2` Banach 完备性 | `ch8s:def:strong-sde-solution`、`ch8s:lem:integral-gronwall`、`ch8s:thm:global-lipschitz-sde`、`ch8s:cor:sde-initial-stability`、`ch8s:prop:ou-explicit-solution`、`ch8s:prop:geometric-brownian` |

随机分析的证明次序为：连续局部鞅与有界抽样、离散平方和估计、ucp 二次变差及停止相容性、
可预测 σ-代数、连续过程的 bracket 与有限变差项、Brownian bracket、可预测阶梯过程的稠密性、
阶梯积分的条件正交与等距、`L^2` 完备延拓、停止积分恒等式、局部化、积分 bracket、分割 Taylor
极限，最后得到一维/时间依赖 Itô 公式、多维公式、扩散 Dynkin/Feynman--Kac 验证和全局
Lipschitz SDE 的 Picard 构造。

分割逼近中，Itô 左端点和的正文陈述采用完整小区间；证明由阶梯积分得到含最后截断增量的
版本，再以 Brownian 路径模连续度一致消去两版本之差。时间依赖公式另对
$\partial_{xx}F(t_{k-1},B_{t_{k-1}})$ 的加权平方增量给出条件正交的 Doob--$L^2$ 估计，
并单独控制未完成区间及左端点 Riemann 和；局部化使用有界停时
$\tau_R\wedge T$。积分型 Gronwall 的适用条件是
`a,c >= 0`，且被控函数可测并局部有界。

在本章中，“Brownian 运动”与滤过同时出现时，指相对于该滤过的 Brownian 运动：过程适应，
且未来增量独立于当前信息。通常增广自然滤过的这一性质由
`ch8b:prop:augmented-fixed-time-independence` 给出；不带滤过的路径律定义本身不包含这一条件。

相关公式的标签为：Itô 等距 `ch8s:eq:ito-isometry`，积分 bracket
`ch8s:eq:ito-integral-bracket`，Brownian 公式 `ch8s:eq:brownian-ito-formula`，一维 Itô 过程公式
`ch8s:eq:ito-process-formula`，多维公式 `ch8s:eq:multidimensional-ito`，Feynman--Kac 验证式
`ch8s:eq:feynman-kac-verification`，以及 SDE 二阶最大矩界 `ch8s:eq:sde-second-moment-bound`。

## 已建立范围与明确边界

当前正文已经建立概率空间上一般保测变换的 Poincaré 返归、von Neumann 与 Birkhoff 遍历定理、
遍历性/强混合及三类经典离散时间模型，以及标准 Borel 状态严格平稳序列的路径移位表示与
时间平均定理。正文还建立一般连续局部鞅的二次变差/协变差、连续鞅的有界可选抽样与 class D 闭合、
以 Brownian 运动为积分器的可预测 `L^2` 和局部平方可积 Itô 积分、Brownian/一维 Brownian 驱动
Itô 过程/多维 Brownian 驱动过程的 Itô 公式、Feller 生成元与预解式的逆关系、Dynkin 鞅、
Feynman--Kac 验证，以及全局 Lipschitz 系数下一维 SDE 的强存在、路径唯一、初值稳定、OU 与
几何 Brownian 显式解。这些结果构成当前正文关于 Itô 理论的覆盖范围。

遍历论的精确边界是：只处理单个离散时间保测变换及单边严格平稳序列；没有建立遍历分解、
熵理论、弱混合的谱刻画、Kingman 次可加遍历定理、连续时间流、群作用或一般 Kac 公式。
有限 Markov 链的单点/集合 Kac 公式由 Markov 部分的再生方法独立建立，不属于一般遍历论的结论。
随机分析方面，随机积分器仍限于 Brownian 运动；正文没有建立对任意半鞅的通用积分理论，
也没有建立 Girsanov、局部时/Tanaka、弱解与分布唯一性、Yamada--Watanabe、局部 Lipschitz 爆炸
理论，或一般 Feller 过程自动具有强 Markov 性的定理。Feynman--Kac 是对已给经典解的验证，
不反向证明 PDE 经典解的存在与正则性。上述未列出的理论不作为正文证明的前提。
