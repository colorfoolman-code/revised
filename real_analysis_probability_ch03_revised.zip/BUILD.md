# 编译说明

本书使用 XeTeX 引擎。包内 `localtexmf/fonts` 附有正文所需的中文字体，因此不依赖本机安装的 CJK 字体；CTeX、xeCJK、zhnumber 及 `amsmath`、`fontspec`、`tcolorbox`、PGF/TikZ、`cleveref` 等宏包则由 TeX 发行版提供。

## 方式一：Tectonic（推荐，无须预装 TeX Live）

[Tectonic](https://tectonic-typesetting.github.io/) 自带 TeX Live bundle，首次运行时按需下载宏包，并自动反复编译到交叉引用、目录和书签收敛：

```sh
tectonic -X compile main.tex --outdir build --keep-intermediates --keep-logs
```

输出为 `build/main.pdf`。本次交付的 PDF 即以 Tectonic 0.15.0 按上述命令生成。

## 方式二：本机 TeX Live 上的 XeLaTeX

需要 TeX Live 2023 或更新版本（一般由 `texlive-xetex` 和 `texlive-latex-extra` 提供所需宏包）。

在源码包根目录运行（macOS/Linux）：

```sh
bash build.sh
```

Windows，或其他已安装 Python 3 与完整 TeX Live 的系统，可以运行：

```sh
python build.py
```

脚本连续编译三轮，使目录、书签和交叉引用收敛。输出为 `build/real_analysis_probability_ch03_revised.pdf`，每轮控制台记录和最终 `.log` 文件也保存在 `build` 中。包根目录附有本次重新编译并完成排版检查的全书 PDF `real_analysis_probability_ch03_revised.pdf`。

需要改变输出文件名或只运行一轮时，可指定文件名（不带扩展名）及编译轮数：

```sh
bash build.sh review_copy 1
```

Python 脚本使用相同的位置参数，例如 `python build.py review_copy 1`。两个脚本均需能够在命令行中找到 `xelatex`。

两个脚本都会把包内 `localtexmf/tex` 加入 `TEXINPUTS`；该目录在本次交付中为空，宏包一律取自本机 TeX 发行版。Bash 脚本还支持宏包已安装、但文件数据库或预生成格式缺失的精简环境：它会启用实际目录搜索，并在 `build/format` 中生成本机所需的 XeLaTeX 格式；不修改系统目录，也不要求管理员权限。Python 脚本使用系统中已经配置好的 XeLaTeX 格式。

若使用正常配置的完整 TeX Live，也可以手动编译：

```sh
TEXINPUTS=.:localtexmf/tex//: xelatex -interaction=nonstopmode -halt-on-error main.tex
TEXINPUTS=.:localtexmf/tex//: xelatex -interaction=nonstopmode -halt-on-error main.tex
TEXINPUTS=.:localtexmf/tex//: xelatex -interaction=nonstopmode -halt-on-error main.tex
```

正文中文字体为 Noto Sans CJK SC 2.004 Regular/Bold，路径为 `localtexmf/fonts/opentype/public/notocjk`。依赖版本、来源和许可证见 `THIRD_PARTY.md`。

本次以第二章已经完成修订的最新全书源码和 PDF 为底稿，完整重写第三章。
第一、二章及第四至八章正文保留底稿；第三章全部原标签保留，引用由重新编译更新。
`reports` 目录提供以底稿正文第 129—202 页为索引的逐页修改记录、内容保留清单、
终稿核验、本轮的出版编辑语言复核记录，以及交付说明与完整性核查。
原页码与本次重新分页后的页码不可混用。

**请先读 `reports/交付说明与完整性核查.md`**：上一轮交付包缺少字体目录和 99 个
被各报告引用的证据文件，该文件逐项列出了缺失内容及其影响。
